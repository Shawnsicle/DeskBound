Place .png files in this folder to use them as backgrounds for your scenes

Docs: https://www.gbstudio.dev/docs/assets/backgrounds
